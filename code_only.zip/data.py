import numpy as np
import cv2
from datetime import datetime


def image_resize(image, width=None, height=None, inter=cv2.INTER_AREA):
    # initialize the dimensions of the image to be resized and
    # grab the image size
    dim = None
    (h, w) = image.shape[:2]
    # if both the width and height are None, then return the
    # original image
    if width is None and height is None:
        return image
    # check to see if the width is None
    if width is None:
        # calculate the ratio of the height and construct the
        # dimensions
        r = height / float(h)
        dim = (int(w * r), height)
    # otherwise, the height is None
    else:
        # calculate the ratio of the width and construct the
        # dimensions
        r = width / float(w)
        dim = (width, int(h * r))

    # resize the image
    resized = cv2.resize(image, dim, interpolation=inter)
    # return the resized image
    return resized


FONT = cv2.FONT_HERSHEY_COMPLEX
FONT_SCALE = 0.4
FONT_COLOR = (0, 0, 0)
VIDEO_SCALE_RATIO = 0.5
RATIO_OF_BELOW_BOX = 0.30
date = datetime.now().strftime("%d_%m_%Y_%H_%M_%S")
OUTPUT_FILE_NAME = 'C:\\Users\\GRH1COB\\Desktop\\smartcity\\Smartcity\\tracking\\output_video\\{}.mp4'.format("test")
cap = cv2.VideoCapture("Video/test.mp4")
frame = 1
img_path = 'icons/bosch.png'
logo = cv2.imread(img_path, -1)
watermark = image_resize(logo, height=50)
watermark = cv2.cvtColor(watermark, cv2.COLOR_BGR2BGRA)
out = None

while frame is not None:
    ret, frame = cap.read()
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2BGRA)
    frame = cv2.resize(frame, None, fx=VIDEO_SCALE_RATIO, fy=VIDEO_SCALE_RATIO, interpolation=cv2.INTER_LINEAR)
    width = frame.shape[1]
    height = frame.shape[0]
    b_height = round(frame.shape[0] * RATIO_OF_BELOW_BOX)
    blank_image = np.zeros((b_height, width, 3), np.uint8)
    blank_image[np.where((blank_image == [0, 0, 0]).all(axis=2))] = [240, 240, 240]
    overlay = np.zeros((height, width, 4), dtype='uint8')
    watermark_h, watermark_w, watermark_c = watermark.shape
    for i in range(0, watermark_h):
        for j in range(0, watermark_w):
            if watermark[i, j][3] != 0:
                offset = 10
                h_offset = height - watermark_h - offset
                w_offset = height - watermark_w - offset
                overlay[10 + i, 10 + j] = watermark[i, j]
    # text = cv::getTextSize(label, fontface, scale, thickness, & baseline);
    # cv::rectangle(im, or + cv::Point(0, baseline), or + cv::Point(text.width, -text.height), CV_RGB(0, 0,
    #                                                                                                 0), CV_FILLED);
    # text_size = cv2.getTextSize("DeepSense", FONT, FONT_SCALE, 1)
    # pt2 = ((width - int(width * 0.25)) + text_size.width, round(height * 0.1) + text_size.height)
    # cv2.rectangle(frame, (width - int(width * 0.25), round(height * 0.1)), pt2, (0, 0, 0),)
    cv2.putText(frame, "DeepSense", (width - int(width * 0.25), round(height * 0.1)), FONT, 1, (255, 255, 255), 2)
    cv2.addWeighted(overlay, 1, frame, 1, 0, frame)

    frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
    # Car Data
    cv2.putText(blank_image, 'Cars Passed:', (10, 30), FONT, FONT_SCALE, FONT_COLOR, 1)
    cv2.putText(blank_image, 'In Flow 5', (30, 50), FONT, FONT_SCALE, FONT_COLOR, 1)
    cv2.putText(blank_image, 'Out Flow 7', (30, 70), FONT, FONT_SCALE, FONT_COLOR, 1)
    cv2.putText(blank_image, 'Avg In Flow 2', (30, 90), FONT, FONT_SCALE, FONT_COLOR, 1)
    cv2.putText(blank_image, 'Avg Out Flow 0', (30, 110), FONT, FONT_SCALE, FONT_COLOR, 1)

    # Bus Data:

    cv2.putText(blank_image, 'Bus Passed:', (160, 30), FONT, FONT_SCALE, FONT_COLOR, 1)
    cv2.putText(blank_image, 'In Flow 5', (180, 50), FONT, FONT_SCALE, FONT_COLOR, 1)
    cv2.putText(blank_image, 'Out Flow 7', (180, 70), FONT, FONT_SCALE, FONT_COLOR, 1)
    cv2.putText(blank_image, 'Avg In Flow 2', (180, 90), FONT, FONT_SCALE, FONT_COLOR, 1)
    cv2.putText(blank_image, 'Avg Out Flow 0', (180, 110), FONT, FONT_SCALE, FONT_COLOR, 1)

    # Bike Data:
    cv2.putText(blank_image, 'Bikes Passed:', (310, 30), FONT, FONT_SCALE, FONT_COLOR, 1)
    cv2.putText(blank_image, 'In Flow 5', (330, 50), FONT, FONT_SCALE, FONT_COLOR, 1)
    cv2.putText(blank_image, 'Out Flow 7', (330, 70), FONT, FONT_SCALE, FONT_COLOR, 1)
    cv2.putText(blank_image, 'Avg In Flow 2', (330, 90), FONT, FONT_SCALE, FONT_COLOR, 1)
    cv2.putText(blank_image, 'Avg Out Flow 0', (330, 110), FONT, FONT_SCALE, FONT_COLOR, 1)

    # Truck Data:
    cv2.putText(blank_image, 'Truck Passed:', (460, 30), FONT, FONT_SCALE, FONT_COLOR, 1)
    cv2.putText(blank_image, 'In Flow 5', (480, 50), FONT, FONT_SCALE, FONT_COLOR, 1)
    cv2.putText(blank_image, 'Out Flow 7', (480, 70), FONT, FONT_SCALE, FONT_COLOR, 1)
    cv2.putText(blank_image, 'Avg In Flow 2', (480, 90), FONT, FONT_SCALE, FONT_COLOR, 1)
    cv2.putText(blank_image, 'Avg Out Flow 0', (480, 110), FONT, FONT_SCALE, FONT_COLOR, 1)

    # Rickshaw Data:
    cv2.putText(blank_image, 'Rickshaw Passed:', (610, 30), FONT, FONT_SCALE, FONT_COLOR, 1)
    cv2.putText(blank_image, 'In Flow 5', (630, 50), FONT, FONT_SCALE, FONT_COLOR, 1)
    cv2.putText(blank_image, 'Out Flow 7', (630, 70), FONT, FONT_SCALE, FONT_COLOR, 1)
    cv2.putText(blank_image, 'Avg In Flow 2', (630, 90), FONT, FONT_SCALE, FONT_COLOR, 1)
    cv2.putText(blank_image, 'Avg Out Flow 0', (630, 110), FONT, FONT_SCALE, FONT_COLOR, 1)

    # Tractor Data:
    cv2.putText(blank_image, 'Tractor Passed:', (770, 30), FONT, FONT_SCALE, FONT_COLOR, 1)
    cv2.putText(blank_image, 'In Flow 5', (790, 50), FONT, FONT_SCALE, FONT_COLOR, 1)
    cv2.putText(blank_image, 'Out Flow 7', (790, 70), FONT, FONT_SCALE, FONT_COLOR, 1)
    cv2.putText(blank_image, 'Avg In Flow 2', (790, 90), FONT, FONT_SCALE, FONT_COLOR, 1)
    cv2.putText(blank_image, 'Avg Out Flow 0', (790, 110), FONT, FONT_SCALE, FONT_COLOR, 1)

    img = np.row_stack((frame, blank_image))
    fheight = img.shape[0]
    fwidth = img.shape[1]
    if out is None:
        fourcc = cv2.VideoWriter_fourcc(*'DIVX')
        fps = cap.get(cv2.CAP_PROP_FPS)
        out = cv2.VideoWriter(OUTPUT_FILE_NAME, fourcc, fps, (fwidth, fheight), True)
    else:
        out.write(img)
    cv2.imshow("Image", img)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
out.release()
cap.release()
