import os
import tkinter as tk
from datetime import datetime
from multiprocessing import Queue
from time import time as timer
from tkinter import ttk, filedialog

import cv2
import matplotlib
import numpy as np
import seaborn as sns
from PIL import Image, ImageTk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

import MCMC
import run
from ArgumentsHandler import argHandler

global q
q = Queue()
matplotlib.use('TkAgg')


def image_resize(image, width=None, height=None, inter=cv2.INTER_AREA):
    # initialize the dimensions of the image to be resized and
    # grab the image size
    dim = None
    (h, w) = image.shape[:2]
    # if both the width and height are None, then return the
    # original image
    if width is None and height is None:
        return image
    # check to see if the width is None
    if width is None:
        # calculate the ratio of the height and construct the
        # dimensions
        r = height / float(h)
        dim = (int(w * r), height)
    # otherwise, the height is None
    else:
        # calculate the ratio of the width and construct the
        # dimensions
        r = width / float(w)
        dim = (width, int(h * r))

    # resize the image
    resized = cv2.resize(image, dim, interpolation=inter)
    # return the resized image
    return resized


class DeepSense_Traffic_Management(tk.Frame):
    def __init__(self, root):
        tk.Frame.__init__(self, root)
        self.overlay = None
        self.root = root
        self.root.title('DeepSense_Traffic_Management')
        self.root.geometry('1920x1080')
        self.root.iconbitmap('bosch.ico')

        self.pack(fill='both', expand=True)
        # self.background = Image.open('C:/Users/GRH1COB/Desktop/smartcitysmartcitySmartcity/tracking/images/background.jpg')
        # self.background_photo= ImageTk.PhotoImage(self.background.resize((1920,1080)))
        # self.background_label = tk.Label(root,image = self.background_photo)
        # self.background_label.place(x=0,y=0,width = 1920,height = 1080)
        FLAGS = run.manual_seeting()
        self.FLAG = argHandler()
        self.FLAG.setDefaults()
        self.FLAG.update(FLAGS)
        self.options = self.FLAG
        self.stop_video = False
        self.elapsed = 0
        self.car_icon = Image.open('C:/Users/GRH1COB/Desktop/smartcity/Smartcity/tracking/images/car_clip.png')
        self.car_photo = ImageTk.PhotoImage(self.car_icon.resize((40, 40)))
        self.bus_icon = Image.open('C:/Users/GRH1COB/Desktop/smartcity/Smartcity/tracking/images/bus_clip.png')
        self.bus_photo = ImageTk.PhotoImage(self.bus_icon.resize((40, 40)))
        self.motorbike_icon = Image.open(
            'C:/Users/GRH1COB/Desktop/smartcity/Smartcity/tracking/images/motorbike_clip.png')
        self.motorbike_photo = ImageTk.PhotoImage(self.motorbike_icon.resize((40, 40)))
        self.truck_icon = Image.open('C:/Users/GRH1COB/Desktop/smartcity/Smartcity/tracking/images/truck.png')
        self.truck_photo = ImageTk.PhotoImage(self.truck_icon.resize((40, 40)))
        self.three_icon = Image.open('C:/Users/GRH1COB/Desktop/smartcity/Smartcity/tracking/images/three.png')
        self.three_photo = ImageTk.PhotoImage(self.three_icon.resize((40, 40)))
        self.tracktor_icon = Image.open('C:/Users/GRH1COB/Desktop/smartcity/Smartcity/tracking/images/tracktor.png')
        self.tracktor_photo = ImageTk.PhotoImage(self.tracktor_icon.resize((40, 40)))
        self.bosch_icon = Image.open('C:/Users/GRH1COB/Desktop/smartcity/Smartcity/tracking/images/bosch.png')
        self.bosch_photo = ImageTk.PhotoImage(self.bosch_icon.resize((40, 40)))
        self.graph_icon = Image.open('C:/Users/GRH1COB/Desktop/smartcity/Smartcity/tracking/images/graph.png')
        self.graph_photo = ImageTk.PhotoImage(self.graph_icon.resize((150, 150)))

        self.draw = False
        self.drawn_line = None
        self.confirm_line = False
        self.Tracker, self.encoder = self.input_track()
        self.source = self.input_source()

        self.video_canvas = tk.Canvas(self, bg='white')
        self.video_canvas.place(x=40, y=50, height=600, width=900)
        self.video_canvas.bind('<Button-1>', self.onStart)
        self.video_canvas.bind('<B1-Motion>', self.onDraw)
        self.video_canvas.bind('<ButtonRelease-1>', self.onEnd)
        self.video_canvas.bind('<Button-3>', self.confirm)

        self.Initialize_button = tk.Button(self, text="INITIALIZE", command=self.Initial_button)
        self.Initialize_button.place(x=40, y=20, height=25, width=100)
        self.Start_button = tk.Button(self, text="START", command=self.start, bg='RED')
        self.Start_button.place(x=160, y=20, height=25, width=100)
        self.browse_button = tk.Button(self, text='BROWSE FILE', command=self.browse_file)
        self.browse_button.place(x=280, y=20, height=25, width=100)
        self.stop_button = tk.Button(self, text='STOP', command=self.Stop)
        self.stop_button.place(x=400, y=20, height=25, width=100)
        self.replay_button = tk.Button(self, text='REPLAY', command=self.replay)
        self.replay_button.place(x=520, y=20, height=25, width=100)
        self.graph_button = tk.Button(self, text='GRAPH', command=self.graph, state='disabled')
        self.graph_button.place(x=640, y=20, height=25, width=100)

        self.car_passed = ttk.Label(self, compound=tk.TOP,
                                    text='IN FLOW = {}\nOUT FLOW = {}\nAVG.IN FLOW = {}\nAVG. OUT FLOW = {}'.format(
                                        'NA', 'NA', 'NA', 'NA'), image=self.car_photo, justify=tk.RIGHT)
        self.car_passed.place(x=40, y=650, height=150, width=150)
        self.bus_passed = ttk.Label(self, compound=tk.TOP,
                                    text='IN FLOW = {}\nOUT FLOW = {}\nAVG.IN FLOW = {}\nAVG. OUT FLOW = {}'.format(
                                        'NA', 'NA', 'NA', 'NA'), image=self.bus_photo, justify=tk.RIGHT)
        self.bus_passed.place(x=200, y=650, height=150, width=150)
        self.motorbike_passed = ttk.Label(self, compound=tk.TOP,
                                          text='IN FLOW = {}\nOUT FLOW = {}\nAVG.IN FLOW = {}\nAVG. OUT FLOW = {}'.format(
                                              'NA', 'NA', 'NA', 'NA'), image=self.motorbike_photo, justify=tk.RIGHT)
        self.motorbike_passed.place(x=360, y=650, height=150, width=150)
        self.truck_passed = ttk.Label(self, compound=tk.TOP,
                                      text='IN FLOW = {}\nOUT FLOW = {}\nAVG.IN FLOW = {}\nAVG. OUT FLOW = {}'.format(
                                          'NA', 'NA', 'NA', 'NA'), image=self.truck_photo, justify=tk.RIGHT)
        self.truck_passed.place(x=520, y=650, height=150, width=150)
        self.three_passed = ttk.Label(self, compound=tk.TOP,
                                      text='IN FLOW = {}\nOUT FLOW = {}\nAVG.IN FLOW = {}\nAVG. OUT FLOW = {}'.format(
                                          'NA', 'NA', 'NA', 'NA'), image=self.three_photo, justify=tk.RIGHT)
        self.three_passed.place(x=680, y=650, height=150, width=150)
        self.tracktor_passed = ttk.Label(self, compound=tk.TOP,
                                         text='IN FLOW = {}\nOUT FLOW = {}\nAVG.IN FLOW = {}\nAVG. OUT FLOW = {}'.format(
                                             'NA', 'NA', 'NA', 'NA'), image=self.tracktor_photo, justify=tk.RIGHT)
        self.tracktor_passed.place(x=840, y=650, height=150, width=150)
        self.graph1 = ttk.Label(self, compound=tk.TOP, text="Data is being generated", image=self.graph_photo,
                                font=("Tahoma", 10, 'bold'))
        self.graph1.place(x=1200, y=120, height=200, width=300)
        self.graph2 = ttk.Label(self, compound=tk.TOP, text='Data is being generated', image=self.graph_photo,
                                font=("Tahoma", 10, 'bold'))
        self.graph2.place(x=1200, y=520, height=200, width=300)
        self.label = ttk.Label(self, text=' **Average flow is calculated per 20 sec', font=("Tahoma", 8, 'bold'),
                               justify=tk.RIGHT)
        self.label.place(x=1200, y=750, height=25, width=300)
        self.DEEP_label = ttk.Label(self, text='DEEPSENSE', font=("Tahoma", 14, 'bold'), image=self.bosch_photo,
                                    compound=tk.TOP)
        self.DEEP_label.place(x=1200, y=20, height=100, width=300)

        self.pbar = ttk.Progressbar(self, orient=tk.HORIZONTAL, mode='determinate', length=200)
        self.pbar.place(x=40, y=1050)
        self.out = None

    def Initial_button(self):

        self.tfnet = run.Initialize(self.options)

    def start(self):

        self.Start_button.config(bg='Green')
        self.stop_video = False

        self.update()

    def browse_file(self):
        if self.stop_video:
            self.source.release()
            self.confirm_line = False
            filename = filedialog.askopenfilename()
            self.options.demo = filename
            self.source = self.input_source()
            # self.Tracker.frame_width = self.frame_width
            # self.Tracker.frame_height = self.frame_height
            self.Tracker.new_video = True
            self.elapsed = 0
            self.Tracker.frame_count = 0

    def Stop(self):
        self.stop_video = True
        self.Start_button.config(bg='Red')

    def replay(self):
        if self.stop_video:
            self.source.release()

            self.confirm_line = False
            self.source = self.input_source()
            self.Tracker.new_video = True
            self.elapsed = 0
            self.Tracker.frame_count = 0

            self.start()

    def onStart(self, event):
        if not self.confirm_line:
            self.start_x = event.x
            self.start_y = event.y
            self.draw = True
            self.end = False
            event.widget.delete(self.drawn_line)

    def graph(self):

        self.Posterior_in = MCMC.sampler(self.data_2min_in, samples=15000, mu_init=1.5)

        self.Posterior_out = MCMC.sampler(self.data_2min_out, samples=15000, mu_init=1.5)

        self.graph_call()

    def graph_call(self):
        # self.Posterior = MCMC.sampler(self.data_2min, samples=5000, mu_init=1.5)

        print('I am in the graph')
        f_in = Figure(figsize=(4, 3.5), dpi=80)
        f_out = Figure(figsize=(4, 3.5), dpi=80)
        f_in.suptitle("Predicted Traffic IN FLOW")
        f_out.suptitle("Predicted Traffic OUT FLOW")
        # if self.ax!=None:
        #
        #     self.ax.clear()
        #     self.bx.clear()
        self.ax = f_in.add_subplot(111)
        self.bx = f_out.add_subplot(111)

        x = np.linspace(1, 2.5, 800)
        sns.distplot(self.Posterior_in[500:], ax=self.ax, label='estimated posterior')
        sns.distplot(self.Posterior_out[500:], ax=self.bx)
        # post_in = MCMC.calc_posterior_analytical(self.data_2min_in,x,1.6,1)

        # self.ax.plot(x,post,'g', Label = 'analytic posterior')
        _ = self.ax.set(xlabel='AVERAGE', ylabel='BELIEF')
        _ = self.bx.set(xlabel='AVERAGE', ylabel='BELIEF')

        canvas_in = FigureCanvasTkAgg(f_in, self)
        canvas_out = FigureCanvasTkAgg(f_out, self)
        canvas_in.draw()
        canvas_out.draw()
        canvas_in.get_tk_widget().place(x=1080, y=120)
        canvas_out.get_tk_widget().place(x=1080, y=450)
        self.graph_button.config(state='disabled')

    def onDraw(self, event):
        self.line_canvas = event.widget
        if self.draw and self.end == False:
            self.line_canvas.delete(self.drawn_line)
            self.drawn_line = self.line_canvas.create_line(self.start_x, self.start_y, event.x, event.y, fill='red')

    def onEnd(self, event):
        if self.draw:
            self.end_x = event.x
            self.end_y = event.y
            self.end = True
            self.draw = None

    def confirm(self, event):
        self.start = timer()
        self.confirm_line = True
        self.till_last_5sec_in = 0
        self.till_last_5sec_out = 0
        self.data_5sec_in = []
        self.data_5sec_out = []
        self.ax = None
        # self.line_coordinate_video = self.conversion()
        self.Tracker.line_coordinate = self.conversion()

    def conversion(self):
        start_x = round(self.start_x * (self.frame_width / 900))
        end_x = round(self.end_x * (self.frame_width / 900))
        start_y = round(self.start_y * (self.frame_height / 600))
        end_y = round(self.end_y * (self.frame_height / 600))
        line_coordinate = [start_x, start_y, end_x, end_y]
        return line_coordinate

    def input_source(self):
        file = self.options.demo

        if file == 'camera':

            file = 0
            self.frame_rate = 1
            camera = cv2.VideoCapture(file)



        else:
            assert os.path.isfile(file), \
                'file {} does not exist'.format(file)

            camera = cv2.VideoCapture(file)
            self.frame_rate = camera.get(cv2.CAP_PROP_FPS)

            self.frame_height = camera.get(cv2.CAP_PROP_FRAME_HEIGHT)
            self.frame_width = camera.get(cv2.CAP_PROP_FRAME_WIDTH)
            self.Tracker.frame_width = self.frame_width
            self.Tracker.frame_height = self.frame_height
            self.Tracker.frame_rate = self.frame_rate
            fourcc = cv2.VideoWriter_fourcc(*'DIVX')
            # date = datetime.now().strftime("%d_%m_%Y_%H_%M_%S")
            file = file.split("/")[-1].split(".")[0]
            OUTPUT_FILE_NAME = 'C:\\Users\\GRH1COB\\Desktop\\smartcity\\Smartcity\\tracking\\output_video\\{}.mp4'.format(
                file)
            VIDEO_SCALE_RATIO = 0.5
            RATIO_OF_BELOW_BOX = 0.30
            _, frame = camera.read()
            frame = cv2.resize(frame, None, fx=VIDEO_SCALE_RATIO, fy=VIDEO_SCALE_RATIO,
                               interpolation=cv2.INTER_LINEAR)
            width = frame.shape[1]
            height = frame.shape[0]
            b_height = round(frame.shape[0] * RATIO_OF_BELOW_BOX)

            blank_image = np.zeros((b_height, width, 3), np.uint8)
            blank_image[np.where((blank_image == [0, 0, 0]).all(axis=2))] = [240, 240, 240]
            img = np.row_stack((frame, blank_image))
            fheight = img.shape[0]
            fwidth = img.shape[1]
            self.out = cv2.VideoWriter(OUTPUT_FILE_NAME, fourcc, self.frame_rate, (fwidth, fheight), True)

        return camera

    def raw_video(self):
        if self.source.isOpened:
            _, frame = self.source.read()
        return frame

    def input_track(self):
        if self.options.tracker == 'sort':
            from sort.sort import Sort
            encoder = None
            Tracker = Sort()

        return Tracker, encoder

    def get_postprocessed(self):
        frame = self.raw_video()

        if frame is None:
            return None
        if self.Tracker.frame_count >= 1:
            self.Tracker.new_video = False

        preprocessed = self.tfnet.framework.preprocess(frame)

        buffer_inp = list()
        buffer_pre = list()
        buffer_inp.append(frame)
        buffer_pre.append(preprocessed)

        feed_dict = {self.tfnet.inp: buffer_pre}
        net_out = self.tfnet.sess.run(self.tfnet.out, feed_dict)
        for img, single_out in zip(buffer_inp, net_out):
            postprocessed = self.tfnet.framework.postprocess(single_out, img,
                                                             frame_id=self.elapsed, csv_file=None,
                                                             csv=None, mask=None, encoder=self.encoder,
                                                             tracker=self.Tracker)

        return postprocessed

    def update(self):
        if not self.confirm_line:
            self.current_frame = self.raw_video()
        else:

            self.current_frame = self.get_postprocessed()

        if self.stop_video == False:
            if self.current_frame is not None:
                self.cv2_image = cv2.cvtColor(self.current_frame, cv2.COLOR_BGR2RGBA)
                self.photo = ImageTk.PhotoImage(image=Image.fromarray(self.cv2_image).resize((900, 600)))
                self.video_canvas.create_image(0, 0, image=self.photo, anchor=tk.NW)
                # self.car_passed.create_text(fill="darkblue",font="Times 20 italic bold",
                FONT = cv2.FONT_HERSHEY_SIMPLEX
                FONT_SCALE = 0.4
                FONT_SCALE_HEADING = 0.6
                FONT_COLOR = (0, 0, 0)
                VIDEO_SCALE_RATIO = 0.5
                RATIO_OF_BELOW_BOX = 0.30

                frame = cv2.resize(self.current_frame, None, fx=VIDEO_SCALE_RATIO, fy=VIDEO_SCALE_RATIO,
                                   interpolation=cv2.INTER_LINEAR)
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2BGRA)
                width = frame.shape[1]
                height = frame.shape[0]
                img_path = 'icons/bosch.png'
                logo = cv2.imread(img_path, -1)
                watermark = image_resize(logo, height=50)
                watermark = cv2.cvtColor(watermark, cv2.COLOR_BGR2BGRA)
                overlay = np.zeros((height, width, 4), dtype='uint8')
                watermark_h, watermark_w, watermark_c = watermark.shape
                for i in range(0, watermark_h):
                    for j in range(0, watermark_w):
                        if watermark[i, j][3] != 0:
                            overlay[10 + i, 10 + j] = watermark[i, j]
                cv2.addWeighted(overlay, 1, frame, 1, 0, frame)
                frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
                width = frame.shape[1]
                height = round(frame.shape[0] * RATIO_OF_BELOW_BOX)
                blank_image = np.zeros((height, width, 3), np.uint8)
                blank_image[np.where((blank_image == [0, 0, 0]).all(axis=2))] = [240, 240, 240]
                cv2.putText(frame, "DeepSense", (width - int(width * 0.25), round(height * 0.2)), FONT, 1,
                            (255, 255, 255), 2)
                if self.confirm_line:
                    self.elapsed += 1

                    vehicle_count = self.Tracker.rama
                    self.car_passed.config(
                        text='IN FLOW = {}\nOUT FLOW = {}\nAVG.IN FLOW = {}\n AVG. OUT FLOW = {}'.format(
                            vehicle_count[0], vehicle_count[4], vehicle_count[7], vehicle_count[10]))
                    self.bus_passed.config(
                        text='IN FLOW = {}\nOUT FLOW = {}\nAVG.IN FLOW = {}\n AVG. OUT FLOW = {}'.format(
                            vehicle_count[1], vehicle_count[5], vehicle_count[8], vehicle_count[11]))
                    self.motorbike_passed.config(
                        text='IN FLOW = {} \nOUT FLOW = {}\nAVG.IN FLOW = {}\n AVG. OUT FLOW = {}'.format(
                            vehicle_count[2], vehicle_count[6], vehicle_count[9], vehicle_count[12]))

                    if self.elapsed % (5 * self.frame_rate) == 0:
                        total_current_in = vehicle_count[0] + vehicle_count[1] + vehicle_count[2]
                        total_current_out = vehicle_count[4] + vehicle_count[5] + vehicle_count[6]
                        bet_5sec_in = total_current_in - self.till_last_5sec_in
                        bet_5sec_out = total_current_out - self.till_last_5sec_out
                        print(self.elapsed / (timer() - self.start))
                        self.data_5sec_in.append(bet_5sec_in)
                        self.data_5sec_out.append(bet_5sec_in)

                        if self.elapsed % (120 * self.frame_rate) == 0:
                            self.graph_button.config(state='normal')
                            print('data received')
                            self.data_2min_in = np.array(self.data_5sec_in)
                            self.data_2min_out = np.array(self.data_5sec_out)
                            self.data_5sec_in = []
                            self.data_5sec_out = []

                        self.till_last_5sec_in = total_current_in
                        self.till_last_5sec_out = total_current_out

                    # Car Data

                    cv2.putText(blank_image, 'Car', (50, 30), FONT, FONT_SCALE_HEADING, FONT_COLOR, 1)
                    cv2.putText(blank_image, 'In Flow {}'.format(vehicle_count[0]), (30, 50), FONT, FONT_SCALE,
                                FONT_COLOR, 1)
                    cv2.putText(blank_image, 'Out Flow {}'.format(vehicle_count[4]), (30, 70), FONT, FONT_SCALE,
                                FONT_COLOR, 1)
                    cv2.putText(blank_image, 'Avg In Flow {}'.format(vehicle_count[7]), (30, 90), FONT, FONT_SCALE,
                                FONT_COLOR, 1)
                    cv2.putText(blank_image, 'Avg Out Flow {}'.format(vehicle_count[10]), (30, 110), FONT,
                                FONT_SCALE, FONT_COLOR, 1)

                    # Truck Data:

                    cv2.putText(blank_image, 'Bus', (200, 30), FONT, FONT_SCALE_HEADING, FONT_COLOR, 1)
                    cv2.putText(blank_image, 'In Flow {}'.format(vehicle_count[1]), (180, 50), FONT, FONT_SCALE,
                                FONT_COLOR, 1)
                    cv2.putText(blank_image, 'Out Flow {}'.format(vehicle_count[5]), (180, 70), FONT, FONT_SCALE,
                                FONT_COLOR, 1)
                    cv2.putText(blank_image, 'Avg In Flow {}'.format(vehicle_count[8]), (180, 90), FONT, FONT_SCALE,
                                FONT_COLOR, 1)
                    cv2.putText(blank_image, 'Avg Out Flow {}'.format(vehicle_count[11]), (180, 110), FONT,
                                FONT_SCALE, FONT_COLOR, 1)

                    # Bike Data:
                    cv2.putText(blank_image, 'Bike', (350, 30), FONT, FONT_SCALE_HEADING, FONT_COLOR, 1)
                    cv2.putText(blank_image, 'In Flow {}'.format(vehicle_count[2]), (330, 50), FONT, FONT_SCALE,
                                FONT_COLOR, 1)
                    cv2.putText(blank_image, 'Out Flow {}'.format(vehicle_count[6]), (330, 70), FONT, FONT_SCALE,
                                FONT_COLOR, 1)
                    cv2.putText(blank_image, 'Avg In Flow {}'.format(vehicle_count[9]), (330, 90), FONT, FONT_SCALE,
                                FONT_COLOR, 1)
                    cv2.putText(blank_image, 'Avg Out Flow {}'.format(vehicle_count[12]), (330, 110), FONT,
                                FONT_SCALE, FONT_COLOR, 1)
                    # Truck Data:
                    cv2.putText(blank_image, 'Truck', (500, 30), FONT, FONT_SCALE_HEADING, FONT_COLOR, 1)
                    cv2.putText(blank_image, 'In Flow {}'.format(None), (480, 50), FONT, FONT_SCALE, FONT_COLOR, 1)
                    cv2.putText(blank_image, 'Out Flow {}'.format(None), (480, 70), FONT, FONT_SCALE, FONT_COLOR, 1)
                    cv2.putText(blank_image, 'Avg In Flow {}'.format(None), (480, 90), FONT, FONT_SCALE, FONT_COLOR, 1)
                    cv2.putText(blank_image, 'Avg Out Flow {}'.format(None), (480, 110), FONT, FONT_SCALE, FONT_COLOR,
                                1)

                    # Rickshaw Data:
                    cv2.putText(blank_image, 'Auto-Rickshaw', (610, 30), FONT, FONT_SCALE_HEADING, FONT_COLOR, 1)
                    cv2.putText(blank_image, 'In Flow {}'.format(None), (630, 50), FONT, FONT_SCALE, FONT_COLOR, 1)
                    cv2.putText(blank_image, 'Out Flow {}'.format(None), (630, 70), FONT, FONT_SCALE, FONT_COLOR, 1)
                    cv2.putText(blank_image, 'Avg In Flow {}'.format(None), (630, 90), FONT, FONT_SCALE, FONT_COLOR, 1)
                    cv2.putText(blank_image, 'Avg Out Flow {}'.format(None), (630, 110), FONT, FONT_SCALE, FONT_COLOR,
                                1)

                    # Tractor Data:
                    cv2.putText(blank_image, 'Tractor', (810, 30), FONT, FONT_SCALE_HEADING, FONT_COLOR, 1)
                    cv2.putText(blank_image, 'In Flow {}'.format(None), (790, 50), FONT, FONT_SCALE, FONT_COLOR, 1)
                    cv2.putText(blank_image, 'Out Flow {}'.format(None), (790, 70), FONT, FONT_SCALE, FONT_COLOR, 1)
                    cv2.putText(blank_image, 'Avg In Flow {}'.format(None), (790, 90), FONT, FONT_SCALE, FONT_COLOR, 1)
                    cv2.putText(blank_image, 'Avg Out Flow {}'.format(None), (790, 110), FONT, FONT_SCALE, FONT_COLOR,
                                1)

                else:
                    cv2.putText(blank_image, 'Counting Not Turned On', (10, 30), FONT, FONT_SCALE, FONT_COLOR,
                                1)
                if self.out:
                    img = np.row_stack((frame, blank_image))
                    self.out.write(img)
                # print(self.camera_frame_rate())

                self.root.after(20, self.update)


            else:
                self.out.release()
                self.source.release()


root = tk.Tk()

window = DeepSense_Traffic_Management(root)
root.mainloop()

# window  = DeepSense_Traffic_Management()
